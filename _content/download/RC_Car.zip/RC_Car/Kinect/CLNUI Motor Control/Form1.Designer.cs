﻿namespace CLNUI_Motor_Control
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grpControls = new System.Windows.Forms.GroupBox();
            this.btnUpdateAlpha = new System.Windows.Forms.Button();
            this.txtAlpha = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.trkAngle = new System.Windows.Forms.TrackBar();
            this.pbGraph = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMoveToTarget = new System.Windows.Forms.Button();
            this.txtTargetAngle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkEnableLED = new System.Windows.Forms.CheckBox();
            this.tmrAccel = new System.Windows.Forms.Timer(this.components);
            this.grpStatus = new System.Windows.Forms.GroupBox();
            this.lblStatusKinect = new System.Windows.Forms.Label();
            this.cmbKinectList = new System.Windows.Forms.ComboBox();
            this.grpRaw = new System.Windows.Forms.GroupBox();
            this.lblPitch = new System.Windows.Forms.Label();
            this.lblPitchBig = new System.Windows.Forms.Label();
            this.lblRoll = new System.Windows.Forms.Label();
            this.lblAccZ = new System.Windows.Forms.Label();
            this.lblAccY = new System.Windows.Forms.Label();
            this.lblAccX = new System.Windows.Forms.Label();
            this.pbDepth = new System.Windows.Forms.PictureBox();
            this.grpControls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGraph)).BeginInit();
            this.grpStatus.SuspendLayout();
            this.grpRaw.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDepth)).BeginInit();
            this.SuspendLayout();
            // 
            // grpControls
            // 
            this.grpControls.Controls.Add(this.btnUpdateAlpha);
            this.grpControls.Controls.Add(this.txtAlpha);
            this.grpControls.Controls.Add(this.label3);
            this.grpControls.Controls.Add(this.trkAngle);
            this.grpControls.Controls.Add(this.pbGraph);
            this.grpControls.Controls.Add(this.label2);
            this.grpControls.Controls.Add(this.btnMoveToTarget);
            this.grpControls.Controls.Add(this.txtTargetAngle);
            this.grpControls.Controls.Add(this.label1);
            this.grpControls.Controls.Add(this.chkEnableLED);
            this.grpControls.Location = new System.Drawing.Point(8, 195);
            this.grpControls.Name = "grpControls";
            this.grpControls.Size = new System.Drawing.Size(200, 179);
            this.grpControls.TabIndex = 6;
            this.grpControls.TabStop = false;
            this.grpControls.Text = "Controls";
            // 
            // btnUpdateAlpha
            // 
            this.btnUpdateAlpha.Location = new System.Drawing.Point(154, 151);
            this.btnUpdateAlpha.Name = "btnUpdateAlpha";
            this.btnUpdateAlpha.Size = new System.Drawing.Size(37, 21);
            this.btnUpdateAlpha.TabIndex = 10;
            this.btnUpdateAlpha.Text = "Go";
            this.btnUpdateAlpha.UseVisualStyleBackColor = true;
            this.btnUpdateAlpha.Click += new System.EventHandler(this.btnUpdateAlpha_Click);
            // 
            // txtAlpha
            // 
            this.txtAlpha.Location = new System.Drawing.Point(106, 152);
            this.txtAlpha.Name = "txtAlpha";
            this.txtAlpha.Size = new System.Drawing.Size(43, 20);
            this.txtAlpha.TabIndex = 9;
            this.txtAlpha.Text = "0.2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Low-pass filter: α =";
            // 
            // trkAngle
            // 
            this.trkAngle.LargeChange = 31;
            this.trkAngle.Location = new System.Drawing.Point(151, 65);
            this.trkAngle.Maximum = 31;
            this.trkAngle.Minimum = -31;
            this.trkAngle.Name = "trkAngle";
            this.trkAngle.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trkAngle.Size = new System.Drawing.Size(45, 88);
            this.trkAngle.SmallChange = 3;
            this.trkAngle.TabIndex = 7;
            this.trkAngle.TickFrequency = 31;
            this.trkAngle.Scroll += new System.EventHandler(this.trkAngle_Scroll);
            // 
            // pbGraph
            // 
            this.pbGraph.BackColor = System.Drawing.Color.White;
            this.pbGraph.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbGraph.Location = new System.Drawing.Point(9, 71);
            this.pbGraph.Name = "pbGraph";
            this.pbGraph.Size = new System.Drawing.Size(140, 73);
            this.pbGraph.TabIndex = 6;
            this.pbGraph.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(124, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "º";
            // 
            // btnMoveToTarget
            // 
            this.btnMoveToTarget.Location = new System.Drawing.Point(141, 42);
            this.btnMoveToTarget.Name = "btnMoveToTarget";
            this.btnMoveToTarget.Size = new System.Drawing.Size(37, 20);
            this.btnMoveToTarget.TabIndex = 4;
            this.btnMoveToTarget.Text = "Go";
            this.btnMoveToTarget.UseVisualStyleBackColor = true;
            this.btnMoveToTarget.Click += new System.EventHandler(this.btnMoveToTarget_Click);
            // 
            // txtTargetAngle
            // 
            this.txtTargetAngle.Location = new System.Drawing.Point(83, 42);
            this.txtTargetAngle.Name = "txtTargetAngle";
            this.txtTargetAngle.Size = new System.Drawing.Size(43, 20);
            this.txtTargetAngle.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Target Angle:";
            // 
            // chkEnableLED
            // 
            this.chkEnableLED.AutoSize = true;
            this.chkEnableLED.Checked = true;
            this.chkEnableLED.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEnableLED.Location = new System.Drawing.Point(9, 19);
            this.chkEnableLED.Name = "chkEnableLED";
            this.chkEnableLED.Size = new System.Drawing.Size(83, 17);
            this.chkEnableLED.TabIndex = 0;
            this.chkEnableLED.Text = "Enable LED";
            this.chkEnableLED.UseVisualStyleBackColor = true;
            this.chkEnableLED.CheckedChanged += new System.EventHandler(this.chkEnableLED_CheckedChanged);
            // 
            // tmrAccel
            // 
            this.tmrAccel.Tick += new System.EventHandler(this.tmrAccel_Tick);
            // 
            // grpStatus
            // 
            this.grpStatus.Controls.Add(this.lblStatusKinect);
            this.grpStatus.Controls.Add(this.cmbKinectList);
            this.grpStatus.Location = new System.Drawing.Point(8, 8);
            this.grpStatus.Name = "grpStatus";
            this.grpStatus.Size = new System.Drawing.Size(200, 60);
            this.grpStatus.TabIndex = 7;
            this.grpStatus.TabStop = false;
            this.grpStatus.Text = "Status:";
            // 
            // lblStatusKinect
            // 
            this.lblStatusKinect.AutoSize = true;
            this.lblStatusKinect.Location = new System.Drawing.Point(6, 40);
            this.lblStatusKinect.Name = "lblStatusKinect";
            this.lblStatusKinect.Size = new System.Drawing.Size(103, 13);
            this.lblStatusKinect.TabIndex = 1;
            this.lblStatusKinect.Text = "Kinect not detected.";
            // 
            // cmbKinectList
            // 
            this.cmbKinectList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbKinectList.FormattingEnabled = true;
            this.cmbKinectList.Location = new System.Drawing.Point(3, 16);
            this.cmbKinectList.Name = "cmbKinectList";
            this.cmbKinectList.Size = new System.Drawing.Size(194, 21);
            this.cmbKinectList.TabIndex = 0;
            this.cmbKinectList.SelectedIndexChanged += new System.EventHandler(this.cmbKinectList_SelectedIndexChanged);
            // 
            // grpRaw
            // 
            this.grpRaw.Controls.Add(this.lblPitch);
            this.grpRaw.Controls.Add(this.lblPitchBig);
            this.grpRaw.Controls.Add(this.lblRoll);
            this.grpRaw.Controls.Add(this.lblAccZ);
            this.grpRaw.Controls.Add(this.lblAccY);
            this.grpRaw.Controls.Add(this.lblAccX);
            this.grpRaw.Location = new System.Drawing.Point(8, 74);
            this.grpRaw.Name = "grpRaw";
            this.grpRaw.Size = new System.Drawing.Size(200, 115);
            this.grpRaw.TabIndex = 9;
            this.grpRaw.TabStop = false;
            this.grpRaw.Text = "Raw Data";
            // 
            // lblPitch
            // 
            this.lblPitch.AutoSize = true;
            this.lblPitch.Location = new System.Drawing.Point(115, 44);
            this.lblPitch.Name = "lblPitch";
            this.lblPitch.Size = new System.Drawing.Size(34, 13);
            this.lblPitch.TabIndex = 6;
            this.lblPitch.Text = "Pitch:";
            this.lblPitch.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblPitchBig
            // 
            this.lblPitchBig.AutoSize = true;
            this.lblPitchBig.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPitchBig.Location = new System.Drawing.Point(49, 61);
            this.lblPitchBig.Name = "lblPitchBig";
            this.lblPitchBig.Size = new System.Drawing.Size(94, 51);
            this.lblPitchBig.TabIndex = 10;
            this.lblPitchBig.Text = "???";
            this.lblPitchBig.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRoll
            // 
            this.lblRoll.AutoSize = true;
            this.lblRoll.Location = new System.Drawing.Point(115, 22);
            this.lblRoll.Name = "lblRoll";
            this.lblRoll.Size = new System.Drawing.Size(28, 13);
            this.lblRoll.TabIndex = 5;
            this.lblRoll.Text = "Roll:";
            this.lblRoll.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAccZ
            // 
            this.lblAccZ.AutoSize = true;
            this.lblAccZ.Location = new System.Drawing.Point(60, 22);
            this.lblAccZ.Name = "lblAccZ";
            this.lblAccZ.Size = new System.Drawing.Size(17, 13);
            this.lblAccZ.TabIndex = 4;
            this.lblAccZ.Text = "Z:";
            this.lblAccZ.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAccY
            // 
            this.lblAccY.AutoSize = true;
            this.lblAccY.Location = new System.Drawing.Point(9, 44);
            this.lblAccY.Name = "lblAccY";
            this.lblAccY.Size = new System.Drawing.Size(17, 13);
            this.lblAccY.TabIndex = 1;
            this.lblAccY.Text = "Y:";
            this.lblAccY.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAccX
            // 
            this.lblAccX.AutoSize = true;
            this.lblAccX.Location = new System.Drawing.Point(9, 22);
            this.lblAccX.Name = "lblAccX";
            this.lblAccX.Size = new System.Drawing.Size(17, 13);
            this.lblAccX.TabIndex = 0;
            this.lblAccX.Text = "X:";
            this.lblAccX.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pbDepth
            // 
            this.pbDepth.Location = new System.Drawing.Point(211, 1);
            this.pbDepth.Name = "pbDepth";
            this.pbDepth.Size = new System.Drawing.Size(640, 480);
            this.pbDepth.TabIndex = 11;
            this.pbDepth.TabStop = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 481);
            this.Controls.Add(this.pbDepth);
            this.Controls.Add(this.grpRaw);
            this.Controls.Add(this.grpStatus);
            this.Controls.Add(this.grpControls);
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(5);
            this.Text = "CLNUI Motor Control";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grpControls.ResumeLayout(false);
            this.grpControls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trkAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGraph)).EndInit();
            this.grpStatus.ResumeLayout(false);
            this.grpStatus.PerformLayout();
            this.grpRaw.ResumeLayout(false);
            this.grpRaw.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbDepth)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpControls;
        private System.Windows.Forms.Timer tmrAccel;
        private System.Windows.Forms.CheckBox chkEnableLED;
        private System.Windows.Forms.TextBox txtTargetAngle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMoveToTarget;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpStatus;
        private System.Windows.Forms.Label lblStatusKinect;
        private System.Windows.Forms.ComboBox cmbKinectList;
        private System.Windows.Forms.GroupBox grpRaw;
        private System.Windows.Forms.Label lblPitch;
        private System.Windows.Forms.Label lblRoll;
        private System.Windows.Forms.Label lblAccZ;
        private System.Windows.Forms.Label lblAccY;
        private System.Windows.Forms.Label lblAccX;
        private System.Windows.Forms.PictureBox pbGraph;
        private System.Windows.Forms.TrackBar trkAngle;
        private System.Windows.Forms.Label lblPitchBig;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAlpha;
        private System.Windows.Forms.Button btnUpdateAlpha;
        private System.Windows.Forms.PictureBox pbDepth;


    }
}

