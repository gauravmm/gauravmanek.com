﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Threading;
using System.Threading;
using System.IO;
using System.IO.Ports;
using CLNUI;
using System.Runtime.InteropServices;
using System.Windows.Media.Imaging;
using System.Management;

namespace CLNUI_Motor_Control
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        // Initialize variables for use in code.
        private int numDevices = 0;
        private string [] deviceSerialList;
        private IntPtr pMotor = IntPtr.Zero;
        private IntPtr pCamera = IntPtr.Zero;
        private bool cameraIsRunning = false;
        private bool enableLED = true;
        private Bitmap graphBMP;
        private Graphics cx;
        private double alpha = 0.8;
        private double prevy = Double.NegativeInfinity;
        private Thread tProcessCameraImage;
        private NUIImage bmpVideoDataRaw;
        private Bitmap bmpVideoData;
        Dispatcher glob;
        private int processingFrame = 0;
        string lastAction = "_";
        SerialPort arduinoPort;

        private void frmMain_Load(object sender, EventArgs e)
        {
            glob = Dispatcher.CurrentDispatcher;
            // Add handlers
            this.txtTargetAngle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTargetAngle_KeyDown);
            this.txtAlpha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAlpha_KeyDown);
            
            graphBMP = new Bitmap(pbGraph.Width, pbGraph.Height);
            cx = Graphics.FromImage(graphBMP);
            pbGraph.Image = graphBMP;
            bmpVideoDataRaw = new NUIImage(640, 480);

            string tmpPort = AutodetectArduinoPort();
            if (tmpPort == null)
            {
                MessageBox.Show("Arduino not detected!");
            }
            else
            {
                arduinoPort = new SerialPort(tmpPort, 9600);
                arduinoPort.Open();
            }
            
            try
            {
                // Search for connected Kinects, populate cmbKinectList.
                numDevices = CLNUIDevice.GetDeviceCount();
                deviceSerialList = new string[numDevices];

                if (numDevices <= 0)
                {
                    MessageBox.Show("Error: No Kinect device detected!\nPlease plug in a Kinect before running this program.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                for (int i = 0; i < numDevices; ++i)
                {
                    deviceSerialList[i] = CLNUIDevice.GetDeviceSerial(i);
                    cmbKinectList.Items.Add(deviceSerialList[i]);
                }
            }
            catch { MessageBox.Show("Error: CLNUI call failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }

            // Display the status
            if (numDevices > 0)
            {
                lblStatusKinect.Text = numDevices + " device" + (numDevices > 1 ? "s" : "") + " detected.";
                cmbKinectList.SelectedIndex = 0;
            }
            //*
            // Prepare camera delegate
            tProcessCameraImage = new Thread(delegate()
            {
                while (true)
                {
                    if (cameraIsRunning)
                    {
                        //CLNUIDevice.GetCameraDepthFrameRGB32(pCamera, bmpVideoDataRaw.ImageData, 0);
                        if (CLNUIDevice.GetCameraDepthFrameRGB32(pCamera, bmpVideoDataRaw.ImageData, 300))
                        {

                                //*
                                glob.BeginInvoke(DispatcherPriority.Normal, (Action)delegate()
                                {
                                	// Simple lock, relies on the ++ operation being atomic. All
                                	// 	frames recived while in the below critical section are
                                	// 	dropped. The critical section ends with "--processingFrame" 
                                    if (++processingFrame == 1)
                                    {
                                        using (MemoryStream outStream = new MemoryStream())
                                        {
                                            // from System.Media.BitmapImage to System.Drawing.Bitmap 
                                            BitmapEncoder enc = new BmpBitmapEncoder();
                                            BitmapSource tmpbmpsrc = bmpVideoDataRaw.BitmapSource.Clone();
                                            enc.Frames.Add(BitmapFrame.Create(tmpbmpsrc));
                                            enc.Save(outStream);
                                            bmpVideoData = new System.Drawing.Bitmap(outStream);
                                        }
                                        double xbar = 0;
                                        double ybar = 0;
                                        int count = 0;
                                        Color c;

                                        for(int i=0; i<bmpVideoData.Width; i+=10)
                                            for(int j=0; j<bmpVideoData.Height; j+=10){
                                                c = bmpVideoData.GetPixel(i, j);
                                                if (c.R == 0 && c.B == 255 && c.G < 192)
                                                {
                                                    bmpVideoData.SetPixel(i, j, Color.Black);
                                                    ++count;
                                                    xbar += (i - xbar) / count;
                                                    ybar += (j - ybar) / count;
                                                }
                                            }

                                        Graphics ctx = Graphics.FromImage(bmpVideoData);
                                        Pen linedraw = new Pen(Color.White, 5);
                                        int circrad = 90;
                                        double k = Math.PI / 3;
                                        // Draw the control regions;
                                        for (int i = -2; i <= 3; ++i)
                                            ctx.DrawLine(linedraw,
                                                new Point(320 + Convert.ToInt32(circrad * Math.Cos(i * k)), 240 + Convert.ToInt32(circrad * Math.Sin(i * k))),
                                                new Point(320 + Convert.ToInt32(640 * Math.Cos(i * k)), 240 + Convert.ToInt32(480 * Math.Sin(i * k))));
                                        ctx.DrawEllipse(linedraw, new Rectangle(320 - circrad, 240 - circrad, circrad * 2, circrad * 2));
                                        c = Color.Black;

                                        if (count == 0)
                                        {
                                            //sendArduinoCommand("_");
                                        }
                                        else
                                        {
                                            // Is it in the stop circle?
                                            if (Math.Pow(xbar - 320, 2) + Math.Pow(ybar - 240, 2) < Math.Pow(circrad, 2))
                                            {
                                                sendArduinoCommand("_");
                                            }
                                            else
                                            {
                                                //c = Color.Red;
                                                int region = Convert.ToInt32(Math.Floor(Math.Atan2(ybar-240, xbar-320)/Math.PI*3));
                                                region = region > 3 ? -3 : region;
                                                //ctx.DrawString("R: " + region, new Font(Font.SystemFontName, 50.0f), new SolidBrush(Color.Red), new PointF(0, 0));
                                                c = region%2==0? Color.Red:Color.Purple;
                                                string cmd = "";
                                                switch (region)
                                                {
                                                    case  2:
                                                    case -3:
                                                        cmd += "d";
                                                        break;
                                                    case  1:
                                                    case -2:
                                                        cmd += "x";
                                                        break;
                                                    case  0:
                                                    case -1:
                                                        cmd += "a";
                                                        break;
                                                }

                                                if (region < 0)
                                                    cmd += "w";
                                                else
                                                    cmd += "s";
                                                sendArduinoCommand(cmd);
                                            }
                                            ctx.FillEllipse(new SolidBrush(c), new Rectangle(System.Convert.ToInt32(xbar) - 10, System.Convert.ToInt32(ybar) - 10, 20, 20));
                                        }

                                        bmpVideoData.RotateFlip(RotateFlipType.RotateNoneFlipX);
                                        pbDepth.Image = bmpVideoData;
                                    } else {
                                    	// ++processingFrame != 1, implying that another thread is
                                    	// currently in this critical section. Frame dropped here.
                                    }
                                    // End of cricical section. 
                                    --processingFrame;
                                });
                                //*/
                        }
                        Thread.Sleep(50);
                    }
                    else
                        Thread.Sleep(100);
                }
            });
            tProcessCameraImage.IsBackground = true;
            tProcessCameraImage.Start();
            //*/
        }
        private void sendArduinoCommand(string c)
        {
            if (c == lastAction || arduinoPort == null)
                return;
            arduinoPort.Write(c);
            lastAction = c;
            //txtCmdLog.Text = c + "\n" + txtCmdLog.Text.Substring(0, 100);
        }

        private void cmbKinectList_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Destroy old motor/accelerometer
            if(pMotor != IntPtr.Zero) CLNUIDevice.DestroyMotor(pMotor);
            if (pCamera != IntPtr.Zero)
            {
                cameraIsRunning = false;
                CLNUIDevice.DestroyCamera(pCamera);
            }
            // Load the motor pointer
            pMotor = CLNUIDevice.CreateMotor(deviceSerialList[cmbKinectList.SelectedIndex]);
            pCamera = CLNUIDevice.CreateCamera(deviceSerialList[cmbKinectList.SelectedIndex]);
            if (pCamera != IntPtr.Zero && CLNUIDevice.StartCamera(pCamera))
            {
                cameraIsRunning = true;
            }

            tmrAccel.Enabled = true;
        }

        private void tmrAccel_Tick(object sender, EventArgs e)
        {
            if (pMotor == IntPtr.Zero)
                return;

            // Get accelerometer data
            short aX = 0, aY = 0, aZ = 0;
            double rPitch, rRoll; // Pitch and roll in radians

            CLNUIDevice.GetMotorAccelerometer(pMotor, ref aX, ref aY, ref aZ);

            lblAccX.Text = "X: " + aX.ToString();
            lblAccY.Text = "Y: " + aY.ToString();
            lblAccZ.Text = "Z: " + aZ.ToString();

            rPitch = Math.Atan((double)aY / aZ);
            rRoll = Math.Atan((double)aX / aZ);

            lblRoll.Text = "Roll: " + radToDeg(rRoll);
            lblPitch.Text = "Pitch: " + radToDeg(rPitch);

            // Low-pass filter
            if (prevy != Double.NegativeInfinity)
                prevy = alpha * rPitch + (1 - alpha) * prevy;
            else
                prevy = rPitch;

            lblPitchBig.Text = radToDeg(prevy);

            // Graphing
            Pen whiteBkg = new Pen(Color.White, 1.0f);
            cx.DrawImage(graphBMP, new Point(-1, 0));
            cx.DrawLine(whiteBkg, new Point(graphBMP.Width - 1, 0), new Point(graphBMP.Width - 1, graphBMP.Height - 1));
            
            // Graph here
            plotValue(rPitch, Color.Red);
            plotValue(prevy, Color.Blue);

            pbGraph.Image = graphBMP;
        }
        private void plotValue(double rPitch, Color col)
        {
            // Draw with blending:
            double y = (graphBMP.Height * (1 - rPitch / 0.5410520675) / 2);
            int fractionLowerPixel = (int)((y - Math.Floor(y)) * 255); // This is the "intensity" of the lower pixel. The upper pixel has intensity (x-1)
            // Nearest neighbour:
            //cx.FillRectangle(new SolidBrush(Color.Blue), new Rectangle(graphBMP.Width - 2, (int)y, 1, 1));
            // Alpha-Blended:
            if (y <= graphBMP.Height && y >= 0)
            {
                // Draw lower pixel
                cx.FillRectangle(new SolidBrush(Color.FromArgb(fractionLowerPixel, col)), new Rectangle(graphBMP.Width - 2, (int)y, 1, 1));
                // Draw upper pixel
                cx.FillRectangle(new SolidBrush(Color.FromArgb(255 - fractionLowerPixel, col)), new Rectangle(graphBMP.Width - 2, (int)(y - 1), 1, 1));
            }
        }

        private void chkEnableLED_CheckedChanged(object sender, EventArgs e)
        {
            enableLED = chkEnableLED.Checked;

            if (!enableLED)
                changeLEDState(0);
            else
                changeLEDState(1);
        }

        /* Possible states, in order:
         *  LED Off, LED Green, LED Red, LED Orange, LED Blink Green, LED Blink Green, LED Blink Red Orange, LED Blink Red Orange
         */
        private void changeLEDState(int state)
        {
            if (pMotor == IntPtr.Zero)
                return;

            CLNUIDevice.SetMotorLED(pMotor, (byte) (state & 255));
        }

        private string radToDeg(double rad)
        {
            string rv = Math.Round(rad / Math.PI * 180, 1).ToString();
            if (rv.Substring(0, 1) != "-")
                rv = "+" + rv;
            if (rv.IndexOf('.') == -1)
                rv += ".0";
            return rv + "º";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult tmpMsgBox = MessageBox.Show("Please ensure that the motor is on a stable surface\nand is not interrupted during calibration.\nThe motor will automatically move during calibration.", "Calibration", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (tmpMsgBox == DialogResult.Cancel)
                return;
            
            // Move motor into starting position

            // Set the necessary variables for calibration data to be gathered by tmrAccel
        }
        private void btnMoveToTarget_Click(object sender, EventArgs e)
        {
            if (pMotor == IntPtr.Zero)
                return;
            // Check if target angle is in range (-90, 90)
            double angle = Double.Parse(txtTargetAngle.Text);
            if(angle > 31 || angle < -31){
                angle = Math.Min(31, Math.Max(angle, -31));
                txtTargetAngle.Text = Math.Round(angle, 1).ToString();
                MessageBox.Show("Error: Angle out of bounds [-31..31].", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int motorpos = (int) Math.Round((16383 * angle) / 31);
            CLNUIDevice.SetMotorPosition(pMotor, (short)motorpos);
        }

        private void trkAngle_Scroll(object sender, EventArgs e)
        {
            txtTargetAngle.Text = trkAngle.Value.ToString();
            btnMoveToTarget_Click(null, null);
        }

        private void btnUpdateAlpha_Click(object sender, EventArgs e)
        {
            // Update value used for the low-pass filter
            double tmp = Double.Parse(txtAlpha.Text);
            if (tmp >= 0 && tmp <= 1)
            {
                alpha = tmp;
                prevy = Double.NegativeInfinity;
            }
            else
            {
                txtAlpha.Text = alpha.ToString();
            }
        }

        private void txtAlpha_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
                btnUpdateAlpha_Click(null, null);
        }

        private void txtTargetAngle_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
                btnMoveToTarget_Click(null, null);
        }

        // By routeNpingme, on StackOverflow
        // stackoverflow.com/questions/3293889/how-to-auto-detect-arduino-com-port
        private string AutodetectArduinoPort()
        {
            ManagementScope connectionScope = new ManagementScope();
            SelectQuery serialQuery = new SelectQuery("SELECT * FROM Win32_SerialPort");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(connectionScope, serialQuery);

            try
            {
                foreach (ManagementObject item in searcher.Get())
                {
                    string desc = item["Description"].ToString();
                    string deviceId = item["DeviceID"].ToString();

                    if (desc.Contains("Arduino"))
                    {
                        return deviceId;
                    }
                }
            }
            catch (ManagementException e)
            {
                /* Do Nothing */
            }

            return null;
        }

    }
}
