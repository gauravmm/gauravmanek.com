RC Car - an Arduino, Kinect and HTML5 project.
By Gaurav Manek

A description of the contents of this file and other information is available here:
http://www.gauravmanek.com/blog/?p=33

All content in this compressed archive that is not already subject to a license agreement is licensed under a Creative Commons Attribution 3.0 Unported License.
[http://creativecommons.org/licenses/by/3.0/]