<?php
header("Content-type: application/x-javascript");
echo "var php_date=\"".date("r")."\";";
?>