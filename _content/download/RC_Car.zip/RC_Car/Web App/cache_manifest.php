<?php
$files = array("index.html", "date.php"); 

header("Content-Type: text/cache-manifest");
?>
CACHE MANIFEST
# Manifest for Car Controller
# Uses filemtime() to automatically change contents

<?php
foreach ($files as $fn)
	echo $fn."\n# Mod:".filemtime($fn)."\n\n";
?># IMPORTANT Allow for network access for all files not listed above:
# 		This allows the WebSocket connection through
NETWORK:
*
