# Laser grid based camera trigger
# Code for server 
#
# Gaurav Manek, 2012
# http://www.gauravmanek.com/blog/?p=58


import socket
import sys
import BaseHTTPServer
import glob
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer

try:	# From http://ubuntuforums.org/showthread.php?t=1518265
    import serial # Python2
except ImportError:
    import serial3 # Python3

class MyHandler(BaseHTTPServer.BaseHTTPRequestHandler):
	# Smallest possible gif from: http://programming.arantius.com/the+smallest+possible+gif
	smallest_possible_gif = "\x47\x49\x46\x38\x39\x61\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00\x2c\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x44\x01\x00\x3b"
	
	def do_GET(s):
		if s.path.endswith('index.html'):
			f = open('mobile_control.html')
			s.send_response(200)
			s.send_header('Content-type', "text/html")
			s.end_headers()
			s.wfile.write(f.read())
			f.close()
			print "Sent index.html"
			return
						
		if s.path.endswith('.gif'):
			s.send_response(200)
			s.send_header('Content-type', "image/gif")
			s.end_headers()
			s.wfile.write(MyHandler.smallest_possible_gif)
			if s.path.endswith('e.gif'):
				# Send serial enable command
				ser.write('e')
				print "Enabled Laser"
				return
			# Replace the text between the two underscores with the password you want to use
			# The default password is password.
			if s.path.endswith('_password_d.gif'):
				# Send serial disable command
				ser.write('d')
				print "Disabled Laser" 
				return
			print "Invalid .gif request"
			return
			
		s.send_response(301)
		s.send_header('Location', "index.html")
		s.end_headers()
		return

def getArduinoPort():
	portlist = glob.glob('/dev/tty.usbmodem*')
	print "Opening port " + portlist[0]
	return portlist[0]


def main():
	try:
		server = HTTPServer(('', 8680), MyHandler)
		print("Server running...")
		server.serve_forever()
	except KeyboardInterrupt:
		print("Stopping server...")
		server.socket.close()
	
# Prepare serial connection
# Remember to replace tty.usbmodem24121 with your own

ser = serial.Serial(getArduinoPort(), 9600)
	
if __name__ == "__main__":
	main()